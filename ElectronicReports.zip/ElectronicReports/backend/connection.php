<?php
$host = 'localhost'; // адрес сервера
$database = 'mybd'; // имя базы данных
$myuser = 'root'; // имя пользователя
$mypassword = '5203'; // пароль
?>
