<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./css/program.css">
</head>
<body>
    <header>
        <div class="name_page">Старт в IT</div>
        <div class="header_list">
            <a href="./personal.php" class="header_link">В личный кабинет</a>
    </div>
    </header>
    <div class="wrapper">
        <div class="info">
            <p>
                Название: Старт в IT
            </p>
            <p>
                Длительность: 72 часа
            </p>
            <p>
                Количество групп: 3
            </p>
        </div>

        <div class="buttons">
            <button>Редактировать программу</button>
            <button>Удалить программу</button>
        </div>

        <div class="links">
            <a href="./editGroup.php">Группа 1</a>
            <a href="./editGroup.php">Группа 2</a>
            <a href="./editGroup.php">Группа 3</a>
        </div>
    </div>
</body>
</html>
