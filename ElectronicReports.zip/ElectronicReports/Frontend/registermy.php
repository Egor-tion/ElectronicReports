<?php

	session_start();
	if($_SESSION['status'] != 1){
		header('Location: ../index.html');
	}

?>

<!doctype html>
<html lang="ru">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Форма регистрации</title>
  <head>

  <body>
    <h1> Форма регистрации <a href="./personalAdmin.php" class="header_link"> Личный кабинет</a></h1>
    <form action="../backend/check0.php" method="post" accept-charset="utf-8">
      Логин <input name="login" type="text" class="from-control"
        id="login" placeholder="Введите логин"><br>
      Пароль <input name="password" type="text" class="from-control"
        id="password" placeholder="Введите пароль"><br>
        Имя <input name="name" type="text" class="from-control"
          id="name"><br>
          Фамилия <input name="lastname" type="text" class="from-control"
            id="Lastname"><br>
            Отчество <input name="fathers_name" type="text" class="from-control"
              id="fathers_name"><br>
                Дата трудоустройста <input name="employmentDate" type="date" class="from-control"
                  id="employmentDate"><br>
      Статус <input name="status" type="text" class="from-control"
        id="status" placeholder="1 - admin, 0 - user"><br>

      <button class="btn btn-success" type="submit"> Зарегистрироваться </button>
    </form>
  </body>
</html>
