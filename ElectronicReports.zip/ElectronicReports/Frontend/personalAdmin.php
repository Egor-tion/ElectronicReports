<?php

	session_start();
	if($_SESSION['status'] != 1){
		header('Location: ../index.html');
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Account</title>
    <link rel="stylesheet" href="./css/personal.css">
</head>
<body>

    <script src="./js/personal.js"></script>
    <div class="wrapper">
            <header>
                <div class="name_page">Личный кабинет</div>
                <div class="header_list">
                    <a href="../backend/exit.php" class="header_link">Выход</a>
            </div>
            </header>

            <div class="info">
                <p><?php echo $_SESSION['user']["Name"], " ", $_SESSION['user']["Lastname"], " ",  $_SESSION['user']["Fathers_name"] ?></p>
                <p>Должность: админ</p>
                <p>Дата начала работы: <?php echo $_SESSION['user']["EmploymentDate"] ?></p>
                <p>Программы: "Старт в IT"</p>
            </div>

            <div class="reports">
                <h1>Функции:</h1>

                <p>
                    <a href="./allusers.php" class="header_link"> Список пользователей</a>
                </p>

								<p>
                    <a href="./register0.php" class="header_link"> Создание нового пользователя</a>
                </p>

								<p>
                    <a href="#" class="header_link"> Обучаемые</a>
                </p>
            </div>
                </div>
    </div>



</body>
</html>
