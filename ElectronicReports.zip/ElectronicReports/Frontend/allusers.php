<?php
    session_start();
    if($_SESSION['status'] != 1){
        header('Location: ../index.html');
    }
    require_once '../backend/connection.php';
    $mysql = new mysqli($host, $myuser, $mypassword, $database);
    $mysql->query("SET names utf8");

    $result = $mysql->query("SELECT * FROM `userss`");
  $allusers=array();
    foreach ($result as $value) {
      $allusers[] = $value;
    }
    //$allusers = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Account</title>
    <link rel="stylesheet" href="./css/personal.css">
</head>
<body>
  <div class="reports">
      <h1>Пользователи: <a href="./personalAdmin.php" class="header_link">Личная страница</a></h1>

      <?php
        //$rows = mysql_num_rows($result);
        //for($i = 0; $i < $rows; $i++) {
        //  $data[$i] = mysql_fetch_array($result);
        //  echo $data[$i];
        //}
        //for ($i = 0; $i < count($allusers); $i++) {
        //  echo $allusers[i];
        //}
        foreach ($allusers as $value) {
          foreach ($value as $kost) {
              //echo '<a href="./personalAdmin.php" class="header_link">';
              echo $kost."   ";
            }
          echo "</br>";
        }

        //echo $allusers["Name"];

        //foreach ($allusers as $value) {
        //  echo  $value;
        //}
      ?>

  </div>
</body>
</html>
