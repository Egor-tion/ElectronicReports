<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Group</title>
    <link rel="stylesheet" href="./css/edit.css">
</head>
<body>
    <header>
        <div class="name_page">Старт в IT: Группа 1</div>
        <div class="header_list">
            <a href="./personal.php" class="header_link">В личный кабинет</a>
            <a href="./program.php" class="header_link">На страницу программы</a>
        </div>
    </header>

    <div class="wrapper">
        <div class="search">
            <figure>
                <img src="./img/loupe.svg" alt="loupe">
            </figure>
            <input type="text" class="searcher" placeholder="Поиск обучающегося">
            <button>Добавить обучающегося</button>
        </div>

        <div class="list">

        </div>

        .
    </div>
</body>
</html>
